const o="/assets/logo1-BN0NG2pQ.webp";export{o as l};
