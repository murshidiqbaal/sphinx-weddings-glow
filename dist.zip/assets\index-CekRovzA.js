import{r as t}from"./vendor-react-ClmwRu7T.js";import"./vendor-query-DP-rrSrX.js";var e=t.createContext(void 0);function a(r){const o=t.useContext(e);return r||o||"ltr"}export{a as u};
